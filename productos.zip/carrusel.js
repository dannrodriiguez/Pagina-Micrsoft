$(document).ready(function(){                       
    $("#carousel1").CloudCarousel({            
        xPos: 128,
        yPos: 32,
        buttonLeft: $("#left-but"),
        buttonRight: $("#right-but"),
        altBox: $("#alt-text"),
        titleBox: $("#title-text")
    });
});
$(document).ready(function(){
  $(".iniciar").click(function()  {
    
    var user = "Monica";
    var password = "pagina";
                      
    var useringresado = $(".nombre").val();
    var passwordingresado = $(".pass").val();
    
    if (user == useringresado && password == passwordingresado){
        alert("Bienvenida Monica");
    }else{
        alert("Intentelo Nuevamente");
    }
                      
  })
})



